library(testthat)
library(clhs)

test_check("clhs")
