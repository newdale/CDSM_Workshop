## convert output from slab -> SPC

.slab2SPC <- function(x, ...) {
  
  
}
