library(testthat)
library(aqp)

test_check("aqp")
